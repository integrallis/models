__ZN15jmodels_kernels22dot_q4_k_q8_k_row_avx217h9f37dbd8c20d52a9E:
Lfunc_beginN:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	andq	$-32, %rsp
	subq	$64, %rsp
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	32(%rbp), %rbx
	movq	%rbx, %r11
	shrq	$8, %r11
	movq	24(%rbp), %r10
	imulq	%r11, %r10
	movq	%r10, %rax
	shlq	$4, %rax
	leaq	(%rax,%rax,8), %rax
	addq	%r11, %r10
	shlq	$4, %r10
	leaq	(%r10,%r10,8), %r10
	cmpq	%rax, %r10
	jb	LBBN_9
	cmpq	%rsi, %r10
	ja	LBBN_9
	movq	16(%rbp), %r14
	movq	%r11, %r10
	imulq	%r14, %r10
	movq	%r10, %rsi
	addq	%r11, %rsi
	jb	LBBN_10
	cmpq	%r8, %rsi
	ja	LBBN_10
	testq	%r11, %r11
	je	LBBN_5
	addq	%rax, %rdi
	leaq	(%rcx,%r10,4), %rax
	imulq	%r14, %rbx
	leaq	224(%rbx,%rdx), %rcx
	shrq	$4, %rbx
	leaq	(%r9,%rbx,2), %rdx
	shlq	$2, %r11
	vpxor	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	xorl	%esi, %esi
	vpbroadcastb	LCPIN_2(%rip), %ymm2
	vbroadcastss	LCPIN_1(%rip), %xmm3
	.p2align	4
LBBN_7:
	movl	4(%rdi), %r8d
	movl	8(%rdi), %r9d
	movl	12(%rdi), %r10d
	movl	%r8d, %ebx
	andl	$1061109567, %ebx
	movl	%r10d, %r14d
	andl	$252645135, %r14d
	shrl	$2, %r8d
	andl	$808464432, %r8d
	orl	%r14d, %r8d
	movl	%r9d, %r14d
	andl	$1061109567, %r14d
	shrl	$4, %r10d
	andl	$252645135, %r10d
	shrl	$2, %r9d
	andl	$808464432, %r9d
	orl	%r10d, %r9d
	vmovd	%ebx, %xmm4
	vpinsrd	$1, %r8d, %xmm4, %xmm4
	vpinsrd	$2, %r14d, %xmm4, %xmm4
	vpinsrd	$3, %r9d, %xmm4, %xmm4
	vpmovzxbw	%xmm4, %ymm4
	vmovdqa	%xmm4, (%rsp)
	vpbroadcastw	(%rsp), %ymm5
	vpbroadcastw	2(%rsp), %ymm6
	vpbroadcastw	4(%rsp), %ymm7
	vmovdqu	16(%rdi), %ymm8
	vpand	%ymm2, %ymm8, %ymm9
	vpmaddubsw	-224(%rcx), %ymm9, %ymm9
	vpmaddwd	%ymm5, %ymm9, %ymm5
	vmovdqu	48(%rdi), %ymm9
	vpsrlw	$4, %ymm8, %ymm8
	vpand	%ymm2, %ymm8, %ymm8
	vpmaddubsw	-192(%rcx), %ymm8, %ymm8
	vpmaddwd	%ymm6, %ymm8, %ymm6
	vpand	%ymm2, %ymm9, %ymm8
	vpmaddubsw	-160(%rcx), %ymm8, %ymm8
	vpmaddwd	%ymm7, %ymm8, %ymm7
	vpbroadcastw	6(%rsp), %ymm8
	vpaddd	%ymm7, %ymm5, %ymm5
	vpbroadcastw	8(%rsp), %ymm7
	vpaddd	%ymm5, %ymm6, %ymm5
	vmovdqu	80(%rdi), %ymm6
	vpsrlw	$4, %ymm9, %ymm9
	vpand	%ymm2, %ymm9, %ymm9
	vpmaddubsw	-128(%rcx), %ymm9, %ymm9
	vpmaddwd	%ymm8, %ymm9, %ymm8
	vpand	%ymm2, %ymm6, %ymm9
	vpmaddubsw	-96(%rcx), %ymm9, %ymm9
	vpmaddwd	%ymm7, %ymm9, %ymm7
	vpbroadcastw	10(%rsp), %ymm9
	vpaddd	%ymm7, %ymm8, %ymm7
	vpbroadcastw	12(%rsp), %ymm8
	vpaddd	%ymm7, %ymm5, %ymm5
	vmovdqu	112(%rdi), %ymm7
	vpsrlw	$4, %ymm6, %ymm6
	vpand	%ymm2, %ymm6, %ymm6
	vpmaddubsw	-64(%rcx), %ymm6, %ymm6
	vpmaddwd	%ymm6, %ymm9, %ymm6
	vpand	%ymm2, %ymm7, %ymm9
	vpmaddubsw	-32(%rcx), %ymm9, %ymm9
	vpmaddwd	%ymm8, %ymm9, %ymm8
	vpaddd	%ymm6, %ymm8, %ymm6
	vpbroadcastw	14(%rsp), %ymm8
	vpsrlw	$4, %ymm7, %ymm7
	vpand	%ymm2, %ymm7, %ymm7
	vpmaddubsw	(%rcx), %ymm7, %ymm7
	vpmaddwd	%ymm7, %ymm8, %ymm7
	vpinsrw	$0, (%rdi), %xmm0, %xmm8
	vpaddd	%ymm7, %ymm6, %ymm6
	vpaddd	%ymm6, %ymm5, %ymm5
	vcvtph2ps	%xmm8, %xmm6
	vmovdqu	(%rdx,%rsi,8), %xmm7
	vphaddw	16(%rdx,%rsi,8), %xmm7, %xmm7
	vmovss	(%rax,%rsi), %xmm8
	vmulss	%xmm6, %xmm8, %xmm6
	vbroadcastss	%xmm6, %ymm6
	vcvtdq2ps	%ymm5, %ymm5
	vfmadd231ps	%ymm5, %ymm6, %ymm1
	vpinsrw	$0, 2(%rdi), %xmm0, %xmm5
	vextracti128	$1, %ymm4, %xmm4
	vpmaddwd	%xmm7, %xmm4, %xmm4
	vcvtph2ps	%xmm5, %xmm5
	vxorps	%xmm3, %xmm8, %xmm6
	vmulss	%xmm5, %xmm6, %xmm5
	vbroadcastss	%xmm5, %xmm5
	vcvtdq2ps	%xmm4, %xmm4
	vfmadd231ps	%xmm4, %xmm5, %xmm0
	addq	$4, %rsi
	addq	$256, %rcx
	addq	$144, %rdi
	cmpq	%rsi, %r11
	jne	LBBN_7
	jmp	LBBN_8
LBBN_5:
	vxorps	%xmm1, %xmm1, %xmm1
	vpxor	%xmm0, %xmm0, %xmm0
LBBN_8:
	vextractf128	$1, %ymm1, %xmm2
	vaddps	%xmm1, %xmm2, %xmm1
	vshufpd	$1, %xmm1, %xmm1, %xmm2
	vaddps	%xmm2, %xmm1, %xmm1
	vshufpd	$1, %xmm0, %xmm0, %xmm2
	vaddps	%xmm2, %xmm0, %xmm0
	vmovshdup	%xmm1, %xmm2
	vaddss	%xmm2, %xmm1, %xmm1
	vmovshdup	%xmm0, %xmm2
	vaddss	%xmm2, %xmm0, %xmm0
	vaddss	%xmm1, %xmm0, %xmm0
	leaq	-16(%rbp), %rsp
	popq	%rbx
	popq	%r14
	popq	%rbp
	vzeroupper
	retq
LBBN_9:
	leaq	l_anon.dd8b9b3cea2cb14d13b6c4c4746f0365.576(%rip), %rcx
	movq	%rax, %rdi
	movq	%rsi, %rdx
	movq	%r10, %rsi
	callq	__RNvNtNtCs8Tvwocrg46H_4core5slice5index16slice_index_fail
LBBN_10:
	leaq	l_anon.dd8b9b3cea2cb14d13b6c4c4746f0365.577(%rip), %rcx
	movq	%r10, %rdi
	movq	%r8, %rdx
	callq	__RNvNtNtCs8Tvwocrg46H_4core5slice5index16slice_index_fail
Lfunc_endN:
	.cfi_endproc
