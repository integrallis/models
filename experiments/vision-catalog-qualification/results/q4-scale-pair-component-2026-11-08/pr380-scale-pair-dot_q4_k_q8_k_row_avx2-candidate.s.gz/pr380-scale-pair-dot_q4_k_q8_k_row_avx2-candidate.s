__ZN15jmodels_kernels22dot_q4_k_q8_k_row_avx217h9f37dbd8c20d52a9E:
Lfunc_beginN:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r14
	pushq	%rbx
	andq	$-32, %rsp
	subq	$64, %rsp
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	movq	32(%rbp), %rbx
	movq	%rbx, %r11
	shrq	$8, %r11
	movq	24(%rbp), %r10
	imulq	%r11, %r10
	movq	%r10, %rax
	shlq	$4, %rax
	leaq	(%rax,%rax,8), %rax
	addq	%r11, %r10
	shlq	$4, %r10
	leaq	(%r10,%r10,8), %r10
	cmpq	%rax, %r10
	jb	LBBN_9
	cmpq	%rsi, %r10
	ja	LBBN_9
	movq	16(%rbp), %r14
	movq	%r11, %r10
	imulq	%r14, %r10
	movq	%r10, %rsi
	addq	%r11, %rsi
	jb	LBBN_10
	cmpq	%r8, %rsi
	ja	LBBN_10
	testq	%r11, %r11
	je	LBBN_5
	addq	%rax, %rdi
	leaq	(%rcx,%r10,4), %rax
	imulq	%r14, %rbx
	leaq	224(%rbx,%rdx), %rcx
	shrq	$4, %rbx
	leaq	(%r9,%rbx,2), %rdx
	shlq	$2, %r11
	vxorps	%xmm0, %xmm0, %xmm0
	vxorps	%xmm1, %xmm1, %xmm1
	xorl	%esi, %esi
	vpbroadcastb	LCPIN_1(%rip), %ymm2
	.p2align	4
LBBN_7:
	movl	4(%rdi), %r8d
	movl	8(%rdi), %r9d
	movl	12(%rdi), %r10d
	movl	%r8d, %ebx
	andl	$1061109567, %ebx
	movl	%r10d, %r14d
	andl	$252645135, %r14d
	shrl	$2, %r8d
	andl	$808464432, %r8d
	orl	%r14d, %r8d
	movl	%r9d, %r14d
	andl	$1061109567, %r14d
	shrl	$4, %r10d
	andl	$252645135, %r10d
	shrl	$2, %r9d
	andl	$808464432, %r9d
	orl	%r10d, %r9d
	vmovd	%ebx, %xmm3
	vpinsrd	$1, %r8d, %xmm3, %xmm3
	vpinsrd	$2, %r14d, %xmm3, %xmm3
	vpinsrd	$3, %r9d, %xmm3, %xmm3
	vpmovzxbw	%xmm3, %ymm3
	vmovdqa	%xmm3, (%rsp)
	vpbroadcastw	(%rsp), %ymm6
	vpbroadcastw	2(%rsp), %ymm7
	vpbroadcastw	4(%rsp), %ymm8
	vpbroadcastw	6(%rsp), %ymm4
	vpbroadcastw	8(%rsp), %ymm5
	vmovdqu	16(%rdi), %ymm9
	vpand	%ymm2, %ymm9, %ymm10
	vpmaddubsw	-224(%rcx), %ymm10, %ymm10
	vpmaddwd	%ymm6, %ymm10, %ymm6
	vmovdqu	48(%rdi), %ymm10
	vpsrlw	$4, %ymm9, %ymm9
	vpand	%ymm2, %ymm9, %ymm9
	vpmaddubsw	-192(%rcx), %ymm9, %ymm9
	vpmaddwd	%ymm7, %ymm9, %ymm7
	vpand	%ymm2, %ymm10, %ymm9
	vpmaddubsw	-160(%rcx), %ymm9, %ymm9
	vpmaddwd	%ymm8, %ymm9, %ymm8
	vpbroadcastw	10(%rsp), %ymm9
	vpaddd	%ymm6, %ymm8, %ymm6
	vmovdqu	80(%rdi), %ymm8
	vpsrlw	$4, %ymm10, %ymm10
	vpand	%ymm2, %ymm10, %ymm10
	vpmaddubsw	-128(%rcx), %ymm10, %ymm10
	vpaddd	%ymm6, %ymm7, %ymm6
	vpand	%ymm2, %ymm8, %ymm7
	vpmaddubsw	-96(%rcx), %ymm7, %ymm7
	vpmaddwd	%ymm4, %ymm10, %ymm4
	vpmaddwd	%ymm5, %ymm7, %ymm5
	vpbroadcastw	12(%rsp), %ymm7
	vpaddd	%ymm5, %ymm4, %ymm4
	vpaddd	%ymm4, %ymm6, %ymm4
	vmovdqu	112(%rdi), %ymm5
	vpsrlw	$4, %ymm8, %ymm6
	vpand	%ymm2, %ymm6, %ymm6
	vpmaddubsw	-64(%rcx), %ymm6, %ymm6
	vpmaddwd	%ymm6, %ymm9, %ymm6
	vpand	%ymm2, %ymm5, %ymm8
	vpmaddubsw	-32(%rcx), %ymm8, %ymm8
	vpmaddwd	%ymm7, %ymm8, %ymm7
	vpaddd	%ymm7, %ymm6, %ymm6
	vpbroadcastw	14(%rsp), %ymm7
	vpsrlw	$4, %ymm5, %ymm5
	vpand	%ymm2, %ymm5, %ymm5
	vpmaddubsw	(%rcx), %ymm5, %ymm5
	vpmaddwd	%ymm7, %ymm5, %ymm5
	vmovss	(%rdi), %xmm7
	vpaddd	%ymm5, %ymm6, %ymm5
	vbroadcastss	(%rax,%rsi), %xmm6
	vpaddd	%ymm5, %ymm4, %ymm4
	vcvtph2ps	%xmm7, %xmm5
	vmulps	%xmm5, %xmm6, %xmm5
	vmovdqu	(%rdx,%rsi,8), %xmm6
	vphaddw	16(%rdx,%rsi,8), %xmm6, %xmm6
	vbroadcastss	%xmm5, %ymm7
	vcvtdq2ps	%ymm4, %ymm4
	vfmadd231ps	%ymm4, %ymm7, %ymm1
	vextracti128	$1, %ymm3, %xmm3
	vpmaddwd	%xmm6, %xmm3, %xmm3
	vshufps	$85, %xmm5, %xmm5, %xmm4
	vcvtdq2ps	%xmm3, %xmm3
	vfnmadd231ps	%xmm3, %xmm4, %xmm0
	addq	$4, %rsi
	addq	$256, %rcx
	addq	$144, %rdi
	cmpq	%rsi, %r11
	jne	LBBN_7
	jmp	LBBN_8
LBBN_5:
	vxorps	%xmm1, %xmm1, %xmm1
	vxorps	%xmm0, %xmm0, %xmm0
LBBN_8:
	vextractf128	$1, %ymm1, %xmm2
	vaddps	%xmm1, %xmm2, %xmm1
	vshufpd	$1, %xmm1, %xmm1, %xmm2
	vaddps	%xmm2, %xmm1, %xmm1
	vshufpd	$1, %xmm0, %xmm0, %xmm2
	vaddps	%xmm2, %xmm0, %xmm0
	vmovshdup	%xmm1, %xmm2
	vaddss	%xmm2, %xmm1, %xmm1
	vmovshdup	%xmm0, %xmm2
	vaddss	%xmm2, %xmm0, %xmm0
	vaddss	%xmm1, %xmm0, %xmm0
	leaq	-16(%rbp), %rsp
	popq	%rbx
	popq	%r14
	popq	%rbp
	vzeroupper
	retq
LBBN_9:
	leaq	l_anon.dd8b9b3cea2cb14d13b6c4c4746f0365.576(%rip), %rcx
	movq	%rax, %rdi
	movq	%rsi, %rdx
	movq	%r10, %rsi
	callq	__RNvNtNtCs8Tvwocrg46H_4core5slice5index16slice_index_fail
LBBN_10:
	leaq	l_anon.dd8b9b3cea2cb14d13b6c4c4746f0365.577(%rip), %rcx
	movq	%r10, %rdi
	movq	%r8, %rdx
	callq	__RNvNtNtCs8Tvwocrg46H_4core5slice5index16slice_index_fail
Lfunc_endN:
	.cfi_endproc
