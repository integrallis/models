__ZN15jmodels_kernels30dot_q4_k_q8_k_row_ordered_avx217hcba54b08d38801b6E:
Lfunc_beginN:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset %rbp, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register %rbp
	pushq	%r15
	pushq	%r14
	pushq	%rbx
	andq	$-32, %rsp
	subq	$96, %rsp
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	32(%rbp), %rbx
	movq	%rbx, %r11
	shrq	$8, %r11
	movq	24(%rbp), %r10
	imulq	%r11, %r10
	movq	%r10, %rax
	shlq	$4, %rax
	leaq	(%rax,%rax,8), %rax
	addq	%r11, %r10
	shlq	$4, %r10
	leaq	(%r10,%r10,8), %r10
	cmpq	%rax, %r10
	jb	LBBN_9
	cmpq	%rsi, %r10
	ja	LBBN_9
	movq	16(%rbp), %r14
	movq	%r11, %r10
	imulq	%r14, %r10
	movq	%r10, %rsi
	addq	%r11, %rsi
	jb	LBBN_10
	cmpq	%r8, %rsi
	ja	LBBN_10
	testq	%r11, %r11
	je	LBBN_5
	addq	%rax, %rdi
	leaq	(%rcx,%r10,4), %rax
	imulq	%r14, %rbx
	leaq	224(%rbx,%rdx), %rcx
	shrq	$4, %rbx
	leaq	(%r9,%rbx,2), %rdx
	shlq	$2, %r11
	vpxor	%xmm0, %xmm0, %xmm0
	xorl	%esi, %esi
	vpbroadcastb	LCPIN_1(%rip), %ymm1
	.p2align	4
LBBN_7:
	movl	4(%rdi), %r9d
	movl	8(%rdi), %r8d
	movl	12(%rdi), %r10d
	movl	%r9d, %ebx
	movl	%r10d, %r14d
	andl	$1061109567, %ebx
	andl	$252645135, %r14d
	shrl	$2, %r9d
	movl	%r8d, %r15d
	andl	$808464432, %r9d
	andl	$1061109567, %r15d
	shrl	$4, %r10d
	andl	$252645135, %r10d
	orl	%r14d, %r9d
	shrl	$2, %r8d
	andl	$808464432, %r8d
	orl	%r10d, %r8d
	vmovd	%ebx, %xmm2
	vpinsrd	$1, %r9d, %xmm2, %xmm2
	vpinsrd	$2, %r15d, %xmm2, %xmm2
	vpinsrd	$3, %r8d, %xmm2, %xmm2
	vmovdqu	16(%rdi), %ymm4
	vpmovzxbw	%xmm2, %ymm2
	vmovdqu	48(%rdi), %ymm5
	vmovdqu	80(%rdi), %ymm3
	vpand	%ymm1, %ymm4, %ymm6
	vmovdqa	%xmm2, (%rsp)
	vpmaddubsw	-224(%rcx), %ymm6, %ymm6
	vpbroadcastw	(%rsp), %ymm7
	vpsrlw	$4, %ymm4, %ymm4
	vpand	%ymm1, %ymm4, %ymm4
	vpbroadcastw	2(%rsp), %ymm8
	vpmaddubsw	-192(%rcx), %ymm4, %ymm4
	vpbroadcastw	4(%rsp), %ymm9
	vpmaddwd	%ymm7, %ymm6, %ymm6
	vpsrlw	$4, %ymm5, %ymm7
	vpand	%ymm1, %ymm5, %ymm5
	vpmaddwd	%ymm4, %ymm8, %ymm4
	vpmaddubsw	-160(%rcx), %ymm5, %ymm5
	vpbroadcastw	6(%rsp), %ymm8
	vpand	%ymm1, %ymm7, %ymm7
	vpmaddubsw	-128(%rcx), %ymm7, %ymm7
	vpmaddwd	%ymm5, %ymm9, %ymm5
	vmovdqu	112(%rdi), %ymm9
	vpmaddwd	%ymm7, %ymm8, %ymm7
	vpand	%ymm1, %ymm3, %ymm8
	vpaddd	%ymm5, %ymm6, %ymm5
	vpmaddubsw	-96(%rcx), %ymm8, %ymm6
	vpbroadcastw	8(%rsp), %ymm8
	vpsrlw	$4, %ymm3, %ymm3
	vpmaddwd	%ymm6, %ymm8, %ymm6
	vpbroadcastw	10(%rsp), %ymm8
	vpand	%ymm1, %ymm3, %ymm3
	vpmaddubsw	-64(%rcx), %ymm3, %ymm3
	vpaddd	%ymm6, %ymm7, %ymm6
	vpmaddwd	%ymm3, %ymm8, %ymm3
	vpand	%ymm1, %ymm9, %ymm7
	vpbroadcastw	12(%rsp), %ymm8
	vpmaddubsw	-32(%rcx), %ymm7, %ymm7
	vpmaddwd	%ymm7, %ymm8, %ymm7
	vpaddd	%ymm7, %ymm3, %ymm3
	vpbroadcastw	14(%rsp), %ymm7
	vpsrlw	$4, %ymm9, %ymm8
	vpaddd	%ymm5, %ymm4, %ymm4
	vpand	%ymm1, %ymm8, %ymm5
	vpmaddubsw	(%rcx), %ymm5, %ymm5
	vmovdqu	(%rdx,%rsi,8), %xmm8
	vphaddw	16(%rdx,%rsi,8), %xmm8, %xmm8
	vpmaddwd	%ymm7, %ymm5, %ymm5
	vpaddd	%ymm5, %ymm3, %ymm3
	vmovss	(%rax,%rsi), %xmm5
	vpaddd	%ymm6, %ymm4, %ymm4
	vpinsrw	$0, (%rdi), %xmm0, %xmm6
	vpaddd	%ymm3, %ymm4, %ymm3
	vextracti128	$1, %ymm3, %xmm4
	vpaddd	%xmm3, %xmm4, %xmm3
	vphaddd	%xmm3, %xmm3, %xmm3
	vpshufd	$85, %xmm3, %xmm4
	vpaddd	%xmm3, %xmm4, %xmm3
	vpinsrw	$0, 2(%rdi), %xmm0, %xmm4
	vcvtph2ps	%xmm6, %xmm6
	vmulss	%xmm6, %xmm5, %xmm6
	vcvtdq2ps	%xmm3, %xmm3
	vfmadd213ss	%xmm0, %xmm6, %xmm3
	vextracti128	$1, %ymm2, %xmm0
	vpmaddwd	%xmm0, %xmm8, %xmm0
	vpshufd	$78, %xmm0, %xmm2
	vpaddd	%xmm0, %xmm2, %xmm0
	vcvtph2ps	%xmm4, %xmm2
	vmulss	%xmm2, %xmm5, %xmm2
	vpshufd	$85, %xmm0, %xmm4
	vpaddd	%xmm0, %xmm4, %xmm0
	vcvtdq2ps	%xmm0, %xmm0
	vfnmadd213ss	%xmm3, %xmm2, %xmm0
	addq	$4, %rsi
	addq	$256, %rcx
	addq	$144, %rdi
	cmpq	%rsi, %r11
	jne	LBBN_7
	jmp	LBBN_8
LBBN_5:
	vpxor	%xmm0, %xmm0, %xmm0
LBBN_8:
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r14
	popq	%r15
	popq	%rbp
	vzeroupper
	retq
LBBN_9:
	leaq	l_anon.dd8b9b3cea2cb14d13b6c4c4746f0365.576(%rip), %rcx
	movq	%rax, %rdi
	movq	%rsi, %rdx
	movq	%r10, %rsi
	callq	__RNvNtNtCs8Tvwocrg46H_4core5slice5index16slice_index_fail
LBBN_10:
	leaq	l_anon.dd8b9b3cea2cb14d13b6c4c4746f0365.577(%rip), %rcx
	movq	%r10, %rdi
	movq	%r8, %rdx
	callq	__RNvNtNtCs8Tvwocrg46H_4core5slice5index16slice_index_fail
Lfunc_endN:
	.cfi_endproc
